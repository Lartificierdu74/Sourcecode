package fr.frenchwolf.superstaff;


import java.util.Arrays;
import java.util.List;
import java.util.Random;

import org.bukkit.Bukkit;
import org.bukkit.Material;
import org.bukkit.entity.Player;
import org.bukkit.inventory.Inventory;
import org.bukkit.inventory.ItemStack;
import org.bukkit.inventory.meta.ItemMeta;
import org.bukkit.plugin.java.JavaPlugin;


public class Main extends JavaPlugin {
	public String ecu = "§c[Ecusson Non Trouver] §7"; 
	public List<String> idList;
	
	
	@Override
	public void onEnable() {
		saveDefaultConfig();
		if(getConfig().getString("config.ecusson") !=null) {
			ecu = getConfig().getString("config.ecusson").replaceAll("&", "§");
		}
		if(!getDataFolder().exists()) {
			getDataFolder().mkdir();
		}
		
		if(getConfig().getStringList("data") !=null) {
			idList = getConfig().getStringList("data");
		}
		getCommand("superstaff").setExecutor(new Command(this));
		getServer().getPluginManager().registerEvents(new Listener(this), this);
	}
	
	public void openInventoryByID(String id, Player player, Player player2){
		//{m; #1310; #0000; §cSanction; 5; 54:0}	
		Inventory inv = Bukkit.createInventory(null, 54, "§cErreur");
		if(id != "#0000") {
			for(int i=0 ; i < idList.size() ;i++) {
				String aID = idList.get(i);
				aID = aID.replaceAll("\\{", "");
				aID = aID.replaceAll("}", "");
				String[] aIDs = aID.split(";");
				if(aIDs.length == 6) {
					if(aIDs[0].equals("m")) {
						if(aIDs[1].equals(id)) {
							inv = Bukkit.createInventory(null, 54, "§cSS>> §9"+aIDs[3].replaceAll("&", "§"));
							break;
						}
					}
				}
			}
		}else {
			inv = Bukkit.createInventory(null, 54, "§cSS>> §9Menu");
		}
		for(int i = 0; i < idList.size(); i++) {
			String aID = idList.get(i);
			aID = aID.replaceAll("\\{", "");
			aID = aID.replaceAll("}", "");
			String[] aIDs = aID.split(";");
			if(aIDs[2].equals(id)) {
				String[] itemId = aIDs[5].split(":");
				int idtype = Integer.parseInt(itemId[0]);
				int idbyte = Integer.parseInt(itemId[1]);
				@SuppressWarnings("deprecation")
				org.bukkit.inventory.ItemStack item = new org.bukkit.inventory.ItemStack(idtype, 1, (byte) idbyte);
				ItemMeta itemM = item.getItemMeta();
				itemM.setDisplayName(aIDs[3].replaceAll("&", "§"));
				itemM.setLore(Arrays.asList("§8"+aIDs[1]));
				item.setItemMeta(itemM);
				if(Integer.parseInt(aIDs[4]) < 45) {
					inv.setItem(Integer.parseInt(aIDs[4]), item);
				}
			}
		}
		ItemStack item = new ItemStack(Material.DIAMOND_CHESTPLATE, 1);
		ItemMeta itemM = item.getItemMeta();
		itemM.setDisplayName("§e"+player2.getName());
		itemM.setLore(Arrays.asList("§7"+id));
		item.setItemMeta(itemM);
		inv.setItem(49, item);
		player.openInventory(inv);
	}
	
	public String createID() {
		String chars = "ABCDEFGHIJKLMNOPQRSTU0123456789";
		StringBuilder password = new StringBuilder();
		Random rand = new Random();
		password.append("#");
		for(int i = 0; i<4; i++) {
			password.append(chars.charAt(rand.nextInt(chars.length())));
		}
		Integer number = 0;
		for(int i=0; i < idList.size() ;i++){		
			String aID = idList.get(i);
			aID = aID.replaceAll("\\{", "");
			aID = aID.replaceAll("}", "");
			String[] aIDs = aID.split(";");
			if(aIDs[2].equals(password.toString())) {
				number++;
			}
		}
		if(number == 0) {
			return password.toString();
		}else {
			this.createID();
			return null;
		}
	}
}
