package fr.frenchwolf.superstaff;

import java.io.File;
import java.util.Arrays;

import org.bukkit.Bukkit;
import org.bukkit.Material;
import org.bukkit.command.CommandExecutor;
import org.bukkit.command.CommandSender;
import org.bukkit.configuration.file.FileConfiguration;
import org.bukkit.configuration.file.YamlConfiguration;
import org.bukkit.entity.Player;
import org.bukkit.inventory.Inventory;
import org.bukkit.inventory.ItemStack;
import org.bukkit.inventory.meta.ItemMeta;


public class Command implements CommandExecutor {
	private Main main;
	public Command(Main main) {
		this.main = main;
	}

	@SuppressWarnings("deprecation")
	@Override
	public boolean onCommand(CommandSender arg0, org.bukkit.command.Command arg1, String arg2, String[] arg3) {
		if(arg0 instanceof Player) {
			Player player = (Player) arg0;
			if(player.hasPermission("ss.use")) {
				if(arg3.length >= 1) {
					if(arg3[0].equalsIgnoreCase("create")){
						if(arg3.length >= 4) {
							if(!arg3[2].equals("§6Configuration")) {
								if(arg3[1].equalsIgnoreCase("menu") || arg3[1].equalsIgnoreCase("sanction")) {
									StringBuffer sb = new StringBuffer();
									for(int i = 0; i < arg3.length; i++) {
										if(i >= 3) {
											sb.append(arg3[i]+ " ");
										}
									}
									Inventory inv = null;
									if(!arg3[2].equals("#0000")) {
										for(int i = 0 ; i <main.idList.size(); i++) {
											String aID = main.idList.get(i);
											aID = aID.replaceAll("\\{", "");
											aID = aID.replaceAll("}", "");
											String[] aIDs = aID.split(";");
											if(aIDs.length == 6) {
												if(aIDs[0].equals("m")){
													if(aIDs[1].equals(arg3[2])) {
														inv = Bukkit.createInventory(null, 54, "§cSS>>§6Configuration");
														ItemStack item = new ItemStack(Material.CHEST, 1);
														ItemMeta itemM = item.getItemMeta();
														itemM.setDisplayName("§eRajouter l'item que vous voulez !");
														itemM.setLore(Arrays.asList("§7"+arg3[2]));
														item.setItemMeta(itemM);
														
														ItemStack item2 = new ItemStack(Material.SIGN, 1);
														ItemMeta item2M = item2.getItemMeta();
														item2M.setDisplayName(sb.toString());
														if(arg3[1].equalsIgnoreCase("menu")) {
															item2M.setLore(Arrays.asList("m"));
														}else if(arg3[1].equalsIgnoreCase("sanction")) {
															item2M.setLore(Arrays.asList("s"));
														}
														item2.setItemMeta(item2M);
														
														ItemStack item3 = new ItemStack(Material.WOOL, 1, (byte) 13);
														ItemMeta item3M = item3.getItemMeta();
														item3M.setDisplayName("§aAccepter !");
														item3M.setLore(Arrays.asList(" "));
														item3.setItemMeta(item3M);
														
														inv.setItem(49, item);
														inv.setItem(45, item2);
														inv.setItem(53, item3);
														break;
													}
												}
											}
										}
									}else {
										inv = Bukkit.createInventory(null, 54, "§cSS>>§6Configuration");
										ItemStack item = new ItemStack(Material.CHEST, 1);
										ItemMeta itemM = item.getItemMeta();
										itemM.setDisplayName("§eRajouter l'item que vous voulez !");
										itemM.setLore(Arrays.asList("§7#0000"));
										item.setItemMeta(itemM);
										
										ItemStack item2 = new ItemStack(Material.SIGN, 1);
										ItemMeta item2M = item2.getItemMeta();
										item2M.setDisplayName(sb.toString());
										if(arg3[1].equalsIgnoreCase("menu")) {
											item2M.setLore(Arrays.asList("m"));
										}else if(arg3[1].equalsIgnoreCase("sanction")) {
											item2M.setLore(Arrays.asList("s"));
										}
										item2.setItemMeta(item2M);
										
										ItemStack item3 = new ItemStack(Material.WOOL, 1, (byte) 13);
										ItemMeta item3M = item3.getItemMeta();
										item3M.setDisplayName("§aAccepter !");
										item3M.setLore(Arrays.asList(" "));
										item3.setItemMeta(item3M);
										
										inv.setItem(49, item);
										inv.setItem(45, item2);
										inv.setItem(53, item3);
									}
									if(inv != null) {
										String id = inv.getItem(49).getItemMeta().getLore().get(0).replaceAll("§7", "");
										for(int i = 0; i < main.idList.size(); i++) {
											String aID = main.idList.get(i);
											aID = aID.replaceAll("\\{", "");
											aID = aID.replaceAll("}", "");
											String[] aIDs = aID.split(";");
											if(aIDs[2].equals(id)) {
												String[] itemId = aIDs[5].split(":");
												int idtype = Integer.parseInt(itemId[0]);
												int idbyte = Integer.parseInt(itemId[1]);
												org.bukkit.inventory.ItemStack item = new org.bukkit.inventory.ItemStack(idtype, 1, (byte) idbyte);
												ItemMeta itemM = item.getItemMeta();
												itemM.setDisplayName(aIDs[3].replaceAll("&", "§"));
												itemM.setLore(Arrays.asList("§8"+aIDs[1]));
												item.setItemMeta(itemM);
												if(Integer.parseInt(aIDs[4]) < 45) {
													inv.setItem(Integer.parseInt(aIDs[4]), item);
												}
											}
										}
										player.openInventory(inv);
									}else {
										player.sendMessage(main.ecu+"L'inventaire avec l'ID §b" + arg3[2] + " §7n'a pas été trouver !");
									}
								}else {
									player.sendMessage(main.ecu+"§cUsage: §b/ss create <sanction ou menu> <inventaire ID> <name>");
								}
							}else {
								player.sendMessage(main.ecu+"§cNom incorrecte, merci de changer le nom !");
							}
						}else {
							player.sendMessage(main.ecu+"§cUsage: §b/ss create <type> <inventaire ID> <name>");
						}
					}else if(arg3[0].equalsIgnoreCase("config")) {
						if(arg3.length == 2) {
							if(arg3[1].equals("#0000")) {
								Inventory inv = Bukkit.createInventory(null, 54, "§cSS>>§6Configuration");
								for(int e = 0; e < main.idList.size() ; e++) {
									String adress = main.idList.get(e);
									adress = adress.replaceAll("\\{", "");
									adress = adress.replaceAll("}", "");
									String[] adressParts = adress.split(";");
									if(adressParts[2].equals(arg3[1])){
										String[] itemId = adressParts[5].split(":");
										int idtype = Integer.parseInt(itemId[0]);
										int idbyte = Integer.parseInt(itemId[1]);
										org.bukkit.inventory.ItemStack item = new org.bukkit.inventory.ItemStack(idtype, 1, (byte) idbyte);
										ItemMeta itemM = item.getItemMeta();
										itemM.setDisplayName(adressParts[3].replaceAll("&", "§"));
										itemM.setLore(Arrays.asList("§8"+adressParts[1]));
										item.setItemMeta(itemM);
										if(Integer.parseInt(adressParts[4]) < 45) {
											inv.setItem(Integer.parseInt(adressParts[4]), item);
										}
										
										ItemStack item3 = new ItemStack(Material.WOOL, 1, (byte) 13);
										ItemMeta item3M = item3.getItemMeta();
										item3M.setDisplayName("§aAccepter !");
										item3M.setLore(Arrays.asList(" "));
										item3.setItemMeta(item3M);
										inv.setItem(53, item3);
									}
								}
								player.openInventory(inv);
							}else {
								for(int i = 0 ; i < main.idList.size() ; i++) {
									String aID = main.idList.get(i);
									aID = aID.replaceAll("\\{", "");
									aID = aID.replaceAll("}", "");
									String[] aIDs = aID.split(";");
									if(aIDs[1].equals(arg3[1])){
										if(aIDs[0].equals("m")){
											Inventory inv = Bukkit.createInventory(null, 54, "§cSS>>§6Configuration");
											for(int e = 0; e < main.idList.size() ; e++) {
												String adress = main.idList.get(e);
												adress = adress.replaceAll("\\{", "");
												adress = adress.replaceAll("}", "");
												String[] adressParts = adress.split(";");
												if(adressParts[2].equals(arg3[1])){
													String[] itemId = adressParts[5].split(":");
													int idtype = Integer.parseInt(itemId[0]);
													int idbyte = Integer.parseInt(itemId[1]);
													org.bukkit.inventory.ItemStack item = new org.bukkit.inventory.ItemStack(idtype, 1, (byte) idbyte);
													ItemMeta itemM = item.getItemMeta();
													itemM.setDisplayName(adressParts[3].replaceAll("&", "§"));
													itemM.setLore(Arrays.asList("§8"+adressParts[1]));
													item.setItemMeta(itemM);

													if(Integer.parseInt(adressParts[4]) < 45) {
														inv.setItem(Integer.parseInt(adressParts[4]), item);
													}
												}
											}
											
											ItemStack item3 = new ItemStack(Material.WOOL, 1, (byte) 13);
											ItemMeta item3M = item3.getItemMeta();
											item3M.setDisplayName("§aAccepter !");
											item3M.setLore(Arrays.asList(" "));
											item3.setItemMeta(item3M);
											inv.setItem(53, item3);
											
											player.openInventory(inv);
											break;
										}else if (aIDs[0].equals("s")) {
											File fichier = new File(main.getDataFolder()+ File.separator + "data" + File.separator +"sanctions"+ File.separator + arg3[1] +".yml");
											FileConfiguration config = YamlConfiguration.loadConfiguration(fichier);
											if(fichier.exists()) {
												Inventory inv = Bukkit.createInventory(null, 54, "§cSS>>§6Config Sanctions");
												Integer recidive = config.getInt("recidive");
												if(recidive < 45) {
													Integer slot = 0;
													for(int e = 0; e < recidive; e++) {
														ItemStack item = new ItemStack(Material.REDSTONE, 1);
														ItemMeta itemM = item.getItemMeta();
														itemM.setDisplayName("§eRécidive: "+ e);
														itemM.setLore(Arrays.asList("§6Commande: §f" + config.getString("recidive-cmd."+e+".command.cmd"), "§6Executeur: §f" + config.getString("recidive-cmd."+e+".command.executor"), "§8"+arg3[1]));
														item.setItemMeta(itemM);
														inv.setItem(slot, item);
														slot++;
													}
												}
												
												ItemStack item2 = new ItemStack(Material.SIGN, 1);
												ItemMeta item2M = item2.getItemMeta();
												item2M.setDisplayName("§eNombre de Récidive: "+ recidive);
												item2M.setLore(Arrays.asList("§8"+arg3[1]));
												item2.setItemMeta(item2M);
												
												inv.setItem(45, item2);
												
												player.openInventory(inv);
												
											}else {
												player.sendMessage(main.ecu+"§cLa fichier de la sanction §b" + arg3[1] + " §cn'éxiste pas ");
											}

											break;
										}
									}
								}
							}

						}
					}else if(arg3[0].equalsIgnoreCase("delete")) {
						if(arg3[1].equals("#0000")){
							player.sendMessage(main.ecu+"§cLe Menu Principal ne peut étre supprimé !");
						}else {
							for(int e = 0; e < main.idList.size() ; e++) {
								String adress = main.idList.get(e);
								adress = adress.replaceAll("\\{", "");
								adress = adress.replaceAll("}", "");
								String[] adressParts = adress.split(";");
								if(adressParts[1].equals(arg3[1])){
									if(adressParts[0].equals("s")) {
										main.idList.remove(e);
										main.getConfig().set("data", main.idList);
										main.saveConfig();
										File fichier = new File(main.getDataFolder()+ File.separator + "data" + File.separator +"sanctions"+ File.separator + arg3[1]+".yml");
										if(fichier.exists()) {
											fichier.delete();
											player.sendMessage(main.ecu+"§aCette sanction à bien été supprimée !");
											return true;
										}else {
											player.sendMessage(main.ecu +"§cImpossible de trouver le fichier §b"+ arg3[1]+".yml §c!");
											return false;
										}
									}else if(adressParts[0].equals("m")) {
										Integer totalFile = 0;
										Integer removedFile = 0;
										for(int a = 0; a < main.idList.size() ; a ++) {
											String id = main.idList.get(a);
											id = id.replaceAll("\\{", "");
											id = id.replaceAll("}", "");
											String[] idParts = id.split(";");
											if(idParts[2].equals(arg3[1])) {
												totalFile++;
												if(idParts[0].equals("s")) {
													main.idList.remove(a);
													main.getConfig().set("data", main.idList);
													main.saveConfig();
													File fichier = new File(main.getDataFolder()+ File.separator + "data" + File.separator +"sanctions"+ File.separator + idParts[1]+".yml");
													if(fichier.exists()) {
														fichier.delete();
														removedFile++;
													}
												}else {
													main.idList.remove(a);
													main.getConfig().set("data", main.idList);
													main.saveConfig();
													removedFile++;
												}
											}
										}
										for(int a = 0; a < main.idList.size() ; a ++) {
											String id = main.idList.get(a);
											id = id.replaceAll("\\{", "");
											id = id.replaceAll("}", "");
											String[] idParts = id.split(";");
											if(idParts[1].equals(arg3[1])) {
												if(idParts[0].equals("m")) {
													main.idList.remove(a);
													main.getConfig().set("data", main.idList);
													main.saveConfig();
													break;
												}
											}
										}
										if(totalFile == removedFile) {
											player.sendMessage(main.ecu+"§aSupression du menu réussis ("+removedFile+"/"+totalFile+")  ");
											return true;
										}else {
											player.sendMessage(main.ecu+"§eSupression du menu ("+removedFile+"/"+totalFile+")  ");
											return true;
										}
									}
								}
							}
							
							player.sendMessage(main.ecu+"§cL'ID §b"+arg3[1]+" §cn'as pas été trouver !");
						}
					}else {
						try {
							Player player2 = Bukkit.getServer().getPlayer(arg3[0]);
							main.openInventoryByID("#0000", player, player2);
						}catch (Exception e) {
							player.sendMessage(main.ecu+"§cUsage: §b/ss <joueur>");
						}
					}
				}
			}
		}
		return false;
	}
}
