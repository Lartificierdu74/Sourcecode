package fr.frenchwolf.superstaff;

import java.io.File;
import java.util.Arrays;
import java.util.HashMap;
import java.util.Map;

import org.bukkit.Bukkit;
import org.bukkit.Material;
import org.bukkit.configuration.file.FileConfiguration;
import org.bukkit.configuration.file.YamlConfiguration;
import org.bukkit.entity.Player;
import org.bukkit.event.EventHandler;
import org.bukkit.event.inventory.InventoryClickEvent;
import org.bukkit.event.player.AsyncPlayerChatEvent;
import org.bukkit.inventory.Inventory;
import org.bukkit.inventory.ItemStack;
import org.bukkit.inventory.meta.ItemMeta;

public class Listener implements org.bukkit.event.Listener {
	
	Map<Player, String> changeCommand = new HashMap<>();
	
	private Main main;
	public Listener(Main main) {
		this.main = main;
	}
	
	@SuppressWarnings("deprecation")
	@EventHandler
	public void onInvClick(InventoryClickEvent event) {
		Player player = (Player)event.getWhoClicked();
		Inventory inv = event.getInventory();
		if(inv.getTitle().contains("§cSS>>")) {
			if(!inv.getTitle().equals("§cSS>>§6Configuration") && !inv.getTitle().equals("§cSS>>§6Config Sanctions") && !inv.getTitle().equals("§cSS>>§6Confirmation")) {
				event.setCancelled(true);
				if(player.hasPermission("ss.use")) {
					ItemStack current = event.getCurrentItem();
					if(current != null) {
						if(event.getRawSlot() < 45) {
							if(current.getItemMeta() !=null) {
								String id = current.getItemMeta().getLore().get(0).replaceAll("§8", "");
								for(int i =0 ; i <main.idList.size() ;i++) {
									String aID = main.idList.get(i);
									aID = aID.replaceAll("\\{", "");
									aID = aID.replaceAll("}", "");
									String[] aIDs = aID.split(";");
									if(aIDs.length == 6) {
										if(aIDs[1].equals(id)) {
											if(aIDs[0].equals("m")) {
												try {
													Player player2 = Bukkit.getServer().getPlayer(inv.getItem(49).getItemMeta().getDisplayName().replaceAll("§e", ""));
													main.openInventoryByID(id, player, player2);
													break;
												}catch (Exception e) {
													player.sendMessage(main.ecu+"§cImpossible d'éxecuter cela, le joueur §b" + inv.getItem(49).getItemMeta().getDisplayName().replaceAll("§e", "") + " §cc'est déconnécter !");
													break;
												}
											}else {
												Player player2 = null;
												try {
													player2 = Bukkit.getServer().getPlayer(inv.getItem(49).getItemMeta().getDisplayName().replaceAll("§e", ""));
												}catch (Exception e) {
													player.sendMessage(main.ecu+"§cImpossible d'éxecuter cela, le joueur §b" + inv.getItem(49).getItemMeta().getDisplayName().replaceAll("§e", "") + " §cc'est déconnécter !");
													break;
													
												}
												if(player2 != null) {
													Inventory inv2 = Bukkit.createInventory(null, 27, "§cSS>>§6Confirmation");
													
													ItemStack paper = new ItemStack(Material.PAPER, 1);
													ItemMeta paperM = paper.getItemMeta();
													paperM.setDisplayName("§e" + inv.getTitle().replaceAll("§9", "").replaceAll("§cSS>>","")+" §6 >> §e "+current.getItemMeta().getDisplayName());
													paperM.setLore(Arrays.asList(current.getItemMeta().getLore().get(0)));
													paper.setItemMeta(paperM);
													inv2.setItem(0, paper);
													
													File pfichier = new File(main.getDataFolder()+ File.separator + "data" + File.separator +"players"+ File.separator + player2.getUniqueId().toString()+".yml");
													if(!pfichier.exists()) {
														try {
															pfichier.createNewFile();
														}catch (Exception e) {
															e.printStackTrace();
														}
															
													}
													FileConfiguration pconfig = YamlConfiguration.loadConfiguration(pfichier);
													Integer recidivep2;
													Boolean activep2;
													if(pconfig.getConfigurationSection(id) != null) {
														recidivep2 = pconfig.getInt(id+".recidive");
														activep2 = pconfig.getBoolean(id+".active");
													}else {
														pconfig.createSection(id);
														pconfig.set(id+".recidive", 0);
														pconfig.set(id+".active", false);
														recidivep2 = 0;
														activep2 = false;
														try {
															pconfig.save(pfichier);
														}catch (Exception e) {
															e.printStackTrace();
														}
													}
													String statut;
													if(activep2==true){statut="§aActive";}else {statut="§cNon Active";}
													
													ItemStack head = new ItemStack(Material.SKULL_ITEM, 1, (byte) 3);
													ItemMeta headM = head.getItemMeta();
													headM.setDisplayName("§a"+player2.getName());
													headM.setLore(Arrays.asList("§eRécidives: " + recidivep2, "§eSanction: " + statut));
													head.setItemMeta(headM);
													inv2.setItem(13, head);
													
													String[] retourId = main.getConfig().getString("config.menu.retour").split(":");
													int retourtype = Integer.parseInt(retourId[0]);
													int retourbyte = Integer.parseInt(retourId[1]);
													org.bukkit.inventory.ItemStack retour = new org.bukkit.inventory.ItemStack(retourtype, 1, (byte) retourbyte);
													ItemMeta retourM = retour.getItemMeta();
													retourM.setDisplayName("§cRetour");
													retour.setItemMeta(retourM);
													inv2.setItem(26, retour);
													
													String[] acceptId = main.getConfig().getString("config.menu.accepter").split(":");
													int accepttype = Integer.parseInt(acceptId[0]);
													int acceptbyte = Integer.parseInt(acceptId[1]);
													org.bukkit.inventory.ItemStack accept = new org.bukkit.inventory.ItemStack(accepttype, 1, (byte) acceptbyte);
													ItemMeta acceptM = accept.getItemMeta();
													acceptM.setDisplayName("§aAccepter");
													accept.setItemMeta(acceptM);
													inv2.setItem(11, accept);
													
													String[] stopId = main.getConfig().getString("config.menu.annuler").split(":");
													int stoptype = Integer.parseInt(stopId[0]);
													int stopbyte = Integer.parseInt(stopId[1]);
													org.bukkit.inventory.ItemStack stop = new org.bukkit.inventory.ItemStack(stoptype, 1, (byte) stopbyte);
													ItemMeta stopM = stop.getItemMeta();
													stopM.setDisplayName("§cAnnulé");
													stop.setItemMeta(stopM);
													inv2.setItem(15, stop);
													
													player.openInventory(inv2);
												}else {
													player.sendMessage(main.ecu+"§cImpossible d'éxecuter cela, le joueur §b" + inv.getItem(49).getItemMeta().getDisplayName().replaceAll("§e", "") + " §cc'est déconnécter !");
												}
											}
											break;
										}
									}
								}
							}
						}
					}
				}else {
					player.sendMessage(main.ecu+"§cVous n'avez pas l'autorisation (ss.use)");
				}
			}else if(inv.getTitle().equals("§cSS>>§6Confirmation")) {
				ItemStack current = event.getCurrentItem();
				event.setCancelled(true);
				if(current !=null) {
					if(current.equals(inv.getItem(11))) {
						String id = inv.getItem(0).getItemMeta().getLore().get(0).replaceAll("§8", "");
						File fichier = new File(main.getDataFolder()+ File.separator + "data" + File.separator +"sanctions"+ File.separator + id+".yml");
						if(fichier.exists()) {
							FileConfiguration config = YamlConfiguration.loadConfiguration(fichier);
							if(config.getInt("recidive") != 0) {
								File directory = new File(main.getDataFolder()+ File.separator + "data" + File.separator +"players"+ File.separator);
								if(!directory.exists()) {
									directory.mkdir();
								}
								Player player2 = null;
								try {
									player2 = Bukkit.getServer().getPlayer(inv.getItem(13).getItemMeta().getDisplayName().replaceAll("§a", ""));
								}catch (Exception e) {
									player.sendMessage(main.ecu+"§cLe joueur §b" + inv.getItem(13).getItemMeta().getDisplayName().replaceAll("§a", "") + "§c n'est plus en ligne !");
									return;
								}
								if(player2 !=null) {
									File pfichier = new File(main.getDataFolder()+ File.separator + "data" + File.separator +"players"+ File.separator + player2.getUniqueId().toString()+".yml");
									if(!pfichier.exists()) {
										try {
											pfichier.createNewFile();
										}catch (Exception e) {
											e.printStackTrace();
										}
											
									}
									FileConfiguration pconfig = YamlConfiguration.loadConfiguration(pfichier);
									Integer recidivep2;
									Boolean activep2;
									if(pconfig.getConfigurationSection(id) != null) {
										recidivep2 = pconfig.getInt(id+".recidive");
										activep2 = pconfig.getBoolean(id+".active");
									}else {
										pconfig.createSection(id);
										pconfig.set(id+".recidive", 0);
										pconfig.set(id+".active", false);
										recidivep2 = 0;
										activep2 = false;
										try {
											pconfig.save(pfichier);
										}catch (Exception e) {
											e.printStackTrace();
										}
									}
									if(activep2 == false) {
										if(config.getConfigurationSection("recidive-cmd."+recidivep2)!=null) {
											if(config.getString("recidive-cmd."+recidivep2+".command.executor").equals("CONSOLE")) {
												Bukkit.dispatchCommand(Bukkit.getConsoleSender(), config.getString("recidive-cmd."+recidivep2+".command.cmd").replaceAll("<player>", player2.getName()));
											}else if(config.getString("recidive-cmd."+recidivep2+".command.executor").equals("PLAYER")) {
												player.chat("/"+config.getString("recidive-cmd."+recidivep2+".command.cmd").replaceAll("<player>", player2.getName()));
											}
											pconfig.set(id+".recidive", recidivep2+1);
											try {
												pconfig.save(pfichier);
											}catch (Exception e) {
												player.sendMessage(main.ecu+"§cImpossible de sauvegarder le fichier joueur");
												e.printStackTrace();
											}
										}else {
											Integer recidive = config.getInt("recidive");
											if(config.getString("recidive-cmd."+(recidive-1)+".command.executor").equals("CONSOLE")) {
												Bukkit.dispatchCommand(Bukkit.getConsoleSender(), config.getString("recidive-cmd."+(recidive-1)+".command.cmd").replaceAll("<player>", player2.getName()));
											}else if(config.getString("recidive-cmd."+(recidive-1)+".command.executor").equals("PLAYER")) {
												player.chat("/"+config.getString("recidive-cmd."+(recidive-1)+".command.cmd").replaceAll("<player>", player2.getName()));
											}
											pconfig.set(id+".recidive", recidivep2+1);
											try {
												pconfig.save(pfichier);
											}catch (Exception e) {
												player.sendMessage(main.ecu+"§cImpossible de sauvegarder le fichier joueur");
												e.printStackTrace();
											}
											player.sendMessage(main.ecu+"§bLe joueur à atteint le nombre de récidive maximum !");
										}

									}else {
										player.sendMessage(main.ecu+"§cCette sanction à déja été prise à l'encontre du joueur !");
									}
								}else {
									player.sendMessage(main.ecu+"§cLe joueur §b" + inv.getItem(13).getItemMeta().getDisplayName().replaceAll("§a", "") + "§c n'est plus en ligne !");
									return;
								}

							}else {
								player.sendMessage(main.ecu+"§cMerci d'éfféctuer la commande §b/ss config " + id + "§c, afin de configurer cette sanction !");
							}
						}else {
							player.sendMessage(main.ecu+"§cImpossible de charger cette sanction, merci de la re-créée ou de le créer manuellement ("+id+".yml)");
						}
						player.closeInventory();
					}else if(current.equals(inv.getItem(15))) {
						player.closeInventory();
					}
				}
			}else if(inv.getTitle().equals("§cSS>>§6Configuration")) {
				if(player.hasPermission("ss.use.create")) {
					ItemStack current = event.getCurrentItem();
					if(event.getRawSlot() > 44 && event.getRawSlot() < 54) {
						event.setCancelled(true);
						if(current.equals(inv.getItem(53))) {
							if(inv.getItem(45) !=null) {
								Boolean oneItem = false;
								for(int i = 0; i < 45; i++) {
									ItemStack loopitem = inv.getItem(i);
									if(loopitem !=null) {
										if(loopitem.getItemMeta() != null) {
											if(loopitem.getItemMeta().getLore() != null) {
												String id = loopitem.getItemMeta().getLore().get(0).replaceAll("§8", "");
												for(int a = 0; a < main.idList.size(); a++ ) {
													String aID = main.idList.get(a);
													String[] aIDs = aID.split(";");
													if(aIDs[1].equals(id)) {
														StringBuffer sb = new StringBuffer();
														for(int e = 0; e < 6; e++) {
															if(e == 4) {
																sb.append(i+";");
															}else {
																if(e == 5) {
																sb.append(aIDs[e]);
																}else {
																	sb.append(aIDs[e]+";");
																}
															}
														}
														main.idList.set(a, sb.toString());
													}
												}
											}else {
												if(oneItem == false) {
													//{m; #1310; #0000; §cSanction; 5; 54:0}
													String id = main.createID();
													String adress = "{"+inv.getItem(45).getItemMeta().getLore().get(0)+";"+id+";"+inv.getItem(49).getItemMeta().getLore().get(0).replaceAll("§7","")+";"+inv.getItem(45).getItemMeta().getDisplayName()+";"+i+";"+loopitem.getTypeId()+":"+loopitem.getData().getData()+"}";
													main.idList.add(adress);
													if(inv.getItem(45).getItemMeta().getLore().get(0).equals("s")) {
														File fichier = new File(main.getDataFolder()+ File.separator + "data" + File.separator +"sanctions"+ File.separator + id+".yml");
														FileConfiguration config = YamlConfiguration.loadConfiguration(fichier);
														config.set("recidive", 0);
														try {
															config.save(fichier);
														}catch (Exception e) {
															player.sendMessage(main.ecu+"§cImpossible de sauvegarder le fichier, merci de réessayer ou de le créer manuellement ("+id+".yml)");
														}
														
													}
													player.sendMessage(main.ecu+ "Création du code: §b" + adress);
													oneItem = true;
												}
											}
										}else {
											if(oneItem == false) {
												//{m; #1310; #0000; §cSanction; 5; 54:0}
												main.idList.add("{"+inv.getItem(45).getItemMeta().getLore().get(0)+";"+main.createID()+";"+inv.getItem(49).getItemMeta().getLore().get(0).replaceAll("§7","")+";"+inv.getItem(45).getItemMeta().getDisplayName()+";"+i+";"+loopitem.getTypeId()+":"+loopitem.getType().getData().getModifiers()+"}");
												player.sendMessage(main.ecu+ "Création du code: §b{"+inv.getItem(45).getItemMeta().getLore().get(0)+";"+main.createID()+";"+inv.getItem(49).getItemMeta().getLore().get(0).replaceAll("§7","")+";"+inv.getItem(45).getItemMeta().getDisplayName()+";"+i+";"+loopitem.getTypeId()+":"+loopitem.getType().getData().getModifiers()+"}");
												oneItem = true;
											}
										}
									}
								}
								player.closeInventory();
								if(oneItem == true) {
									player.sendMessage(main.ecu+"§bCréation réussi !");
									main.getConfig().set("data",main.idList);
									main.saveConfig();
								}else {
									player.sendMessage(main.ecu+"§cErreur dans la création !");
									main.getConfig().set("data",main.idList);
									main.saveConfig();
								}
								
							}else {
								for(int i = 0; i < 45; i++) {
									ItemStack loopitem = inv.getItem(i);
									if(loopitem !=null) {
										if(loopitem.getItemMeta() != null) {
											if(loopitem.getItemMeta().getLore() != null) {
												String id = loopitem.getItemMeta().getLore().get(0).replaceAll("§8", "");
												for(int a = 0; a < main.idList.size(); a++ ) {
													String aID = main.idList.get(a);
													String[] aIDs = aID.split(";");
													if(aIDs[1].equals(id)) {
														StringBuffer sb = new StringBuffer();
														for(int e = 0; e < 6; e++) {
															if(e == 4) {
																sb.append(i+";");
															}else {
																if(e == 5) {
																	sb.append(aIDs[e]);
																}else {
																	sb.append(aIDs[e]+";");
																}
															}
															main.idList.set(a, sb.toString());
														}
													}
												}
											}
										}
									}
								}
								main.getConfig().set("data",main.idList);
								main.saveConfig();
								player.closeInventory();
								player.sendMessage(main.ecu+"§aModification du Menu réussi !");
							}
						}
					}else if(inv.getItem(45) == null) {
						if(event.getRawSlot() > 44) {
							event.setCancelled(true);
						}
					}
				}
			}else if(inv.getTitle().equals("§cSS>>§6Config Sanctions")) {
				if(inv.getItem(45) !=null) {
					event.setCancelled(true);
					ItemStack current = event.getCurrentItem();
					if(event.getRawSlot() < 44) {
						Inventory inv2 = Bukkit.createInventory(null, 54, "§cSS>>§6Config Sanctions");
						inv2.setItem(22, current);

						ItemStack consoleitem = new ItemStack(Material.TRIPWIRE_HOOK, 1);
						ItemMeta consoleitemM = consoleitem.getItemMeta();
						consoleitemM.setDisplayName("§6Exécuteur: §fCONSOLE");
						consoleitemM.setLore(Arrays.asList(" "));
						consoleitem.setItemMeta(consoleitemM);
						
						ItemStack playeritem = new ItemStack(Material.REDSTONE_TORCH_ON, 1);
						ItemMeta playeritemM = playeritem.getItemMeta();
						playeritemM.setDisplayName("§6Exécuteur: §fPLAYER");
						playeritemM.setLore(Arrays.asList(" "));
						playeritem.setItemMeta(playeritemM);
						
						ItemStack cmd = new ItemStack(Material.STICK, 1);
						ItemMeta cmdM = cmd.getItemMeta();
						cmdM.setDisplayName(current.getItemMeta().getLore().get(0));
						cmdM.setLore(Arrays.asList("§aCliquer pour modifier !"));
						cmd.setItemMeta(cmdM);
						
						if(current.getItemMeta().getLore().get(1).equals("§6Executeur: §fPLAYER")) {
							inv2.setItem(25, playeritem);
						}else {
							inv2.setItem(25, consoleitem);
						}
						
						inv2.setItem(19, cmd);
						player.openInventory(inv2);
						
					}else  {
						if(current.equals(inv.getItem(45))) {
							//File fichier = new File(main.getDataFolder()+ File.separator + "data" + File.separator +"sanctions"+ File.separator + current.getItemMeta().getLore().get(0).replaceAll("§8", "") +".yml");
							//FileConfiguration config = YamlConfiguration.loadConfiguration(fichier);
							Inventory inv2 = Bukkit.createInventory(null, 54, "§cSS>>§6Config Sanctions");
							inv2.setItem(22, current);
							
							ItemStack more1 = new ItemStack(Material.WOOL, 1, (byte) 13);
							ItemMeta more1M = more1.getItemMeta();
							more1M.setDisplayName("§a+1");
							more1M.setLore(Arrays.asList(" "));
							more1.setItemMeta(more1M);
							
							ItemStack more10 = new ItemStack(Material.WOOL, 1, (byte) 13);
							ItemMeta more10M = more10.getItemMeta();
							more10M.setDisplayName("§a+10");
							more10M.setLore(Arrays.asList(" "));
							more10.setItemMeta(more10M);
							
							ItemStack less1 = new ItemStack(Material.WOOL, 1, (byte) 14);
							ItemMeta less1M = less1.getItemMeta();
							less1M.setDisplayName("§c-1");
							less1M.setLore(Arrays.asList(" "));
							less1.setItemMeta(less1M);
							
							ItemStack less10 = new ItemStack(Material.WOOL, 1, (byte) 14);
							ItemMeta less10M = less10.getItemMeta();
							less10M.setDisplayName("§c-10");
							less10M.setLore(Arrays.asList(" "));
							less10.setItemMeta(less10M);
							
							ItemStack okay = new ItemStack(Material.WOOL, 1, (byte) 13);
							ItemMeta okayM = okay.getItemMeta();
							okayM.setDisplayName("§aAccepter ✓");
							okayM.setLore(Arrays.asList(" "));
							okay.setItemMeta(okayM);
							
							inv2.setItem(26, more10);
							inv2.setItem(25, more1);
							
							inv2.setItem(53, okay);
							
							inv2.setItem(18, less10);
							inv2.setItem(19, less1);
							
							player.openInventory(inv2);
						}
					}
				}else if(inv.getItem(53) !=null) {
					event.setCancelled(true);
					ItemStack current = event.getCurrentItem();
					Integer number = Integer.parseInt(inv.getItem(22).getItemMeta().getDisplayName().replaceAll("§eNombre de Récidive: ", ""));
					if(current.equals(inv.getItem(26))) {
						number = number+10;
						if(number > 44) {
							number = 44;
						}
						ItemStack item2 = new ItemStack(Material.SIGN, 1);
						ItemMeta item2M = item2.getItemMeta();
						item2M.setDisplayName("§eNombre de Récidive: "+ number);
						item2M.setLore(inv.getItem(22).getItemMeta().getLore());
						item2.setItemMeta(item2M);
						inv.setItem(22, item2);
					}else if(current.equals(inv.getItem(25))){
						number = number+1;
						if(number > 44) {
							number = 44;
						}
						ItemStack item2 = new ItemStack(Material.SIGN, 1);
						ItemMeta item2M = item2.getItemMeta();
						item2M.setDisplayName("§eNombre de Récidive: "+ number);
						item2M.setLore(inv.getItem(22).getItemMeta().getLore());
						item2.setItemMeta(item2M);
						inv.setItem(22, item2);
					}else if(current.equals(inv.getItem(18))){
						number = number-10;
						if(number < 0) {
							number = 0;
						}
						ItemStack item2 = new ItemStack(Material.SIGN, 1);
						ItemMeta item2M = item2.getItemMeta();
						item2M.setDisplayName("§eNombre de Récidive: "+ number);
						item2M.setLore(inv.getItem(22).getItemMeta().getLore());
						item2.setItemMeta(item2M);
						inv.setItem(22, item2);
					}else if(current.equals(inv.getItem(19))){
						number = number-1;
						if(number < 0) {
							number = 0;
						}
						ItemStack item2 = new ItemStack(Material.SIGN, 1);
						ItemMeta item2M = item2.getItemMeta();
						item2M.setDisplayName("§eNombre de Récidive: "+ number);
						item2M.setLore(inv.getItem(22).getItemMeta().getLore());
						item2.setItemMeta(item2M);
						inv.setItem(22, item2);
					}else if(current.equals(inv.getItem(53))) {
						File fichier = new File(main.getDataFolder()+ File.separator + "data" + File.separator +"sanctions"+ File.separator + inv.getItem(22).getItemMeta().getLore().get(0).replaceAll("§8", "") +".yml");
						FileConfiguration config = YamlConfiguration.loadConfiguration(fichier);
						if(fichier.exists()) {
							config.set("recidive", number);
							for(int i = 0; i < number; i++) {
								if(config.getConfigurationSection("recidive-cmd."+ i) == null){
									config.set("recidive-cmd."+i+".command.executor", "PLAYER");
									config.set("recidive-cmd."+i+".command.cmd", "exemple <player> ban");
								}
							}
							try {
								config.save(fichier);	
							}catch (Exception e) {
								player.sendMessage(main.ecu+"§cLe fichier de cette sanction n'as pas pue étre enregistré !");
							}
							
							for(String string : config.getConfigurationSection("recidive-cmd").getKeys(false)){
								Integer loopnumber = Integer.parseInt(string);
								if(loopnumber >= number) {
									config.set("recidive-cmd."+string, null);
								}
							}
							try {
								config.save(fichier);
								player.sendMessage(main.ecu+"§aLe fichier de cette sanction as bien été modifier !");
							}catch (Exception e) {
								player.sendMessage(main.ecu+"§cLe fichier de cette sanction n'as pas pue étre enregistré !");
							}
						}
						player.closeInventory();
					}
				}else {
					event.setCancelled(true);
					ItemStack current = event.getCurrentItem();
					if(current.equals(inv.getItem(25))) {
						ItemStack consoleitem = new ItemStack(Material.TRIPWIRE_HOOK, 1);
						ItemMeta consoleitemM = consoleitem.getItemMeta();
						consoleitemM.setDisplayName("§6Exécuteur: §fCONSOLE");
						consoleitemM.setLore(Arrays.asList(" "));
						consoleitem.setItemMeta(consoleitemM);
						
						ItemStack playeritem = new ItemStack(Material.REDSTONE_TORCH_ON, 1);
						ItemMeta playeritemM = playeritem.getItemMeta();
						playeritemM.setDisplayName("§6Exécuteur: §fPLAYER");
						playeritemM.setLore(Arrays.asList(" "));
						playeritem.setItemMeta(playeritemM);
						
						if(inv.getItem(25).getType().equals(consoleitem.getType())) {
							inv.setItem(25, playeritem);
							File fichier = new File(main.getDataFolder()+ File.separator + "data" + File.separator +"sanctions"+ File.separator + inv.getItem(22).getItemMeta().getLore().get(2).replaceAll("§8", "") +".yml");
							if(fichier.exists()) {
								FileConfiguration config = YamlConfiguration.loadConfiguration(fichier);
								config.set("recidive-cmd."+inv.getItem(22).getItemMeta().getDisplayName().replaceAll("§eRécidive: ", "")+".command.executor", "PLAYER");
								try {
									config.save(fichier);
								}catch (Exception e) {
									player.sendMessage(main.ecu+"§cLe fichier de cette sanction n'as pas pue étre enregistré !");
								}
							}
						}else {
							inv.setItem(25, consoleitem);
							File fichier = new File(main.getDataFolder()+ File.separator + "data" + File.separator +"sanctions"+ File.separator + inv.getItem(22).getItemMeta().getLore().get(2).replaceAll("§8", "") +".yml");
							if(fichier.exists()) {
								FileConfiguration config = YamlConfiguration.loadConfiguration(fichier);
								config.set("recidive-cmd."+inv.getItem(22).getItemMeta().getDisplayName().replaceAll("§eRécidive: ", "")+".command.executor", "CONSOLE");
								try {
									config.save(fichier);
								}catch (Exception e) {
									player.sendMessage(main.ecu+"§cLe fichier de cette sanction n'as pas pue étre enregistré !");
								}
							}
						}
					}else if(current.equals(inv.getItem(19))) {
						changeCommand.put(player,inv.getItem(22).getItemMeta().getLore().get(2).replaceAll("§8", "")+":"+inv.getItem(22).getItemMeta().getDisplayName().replaceAll("§eRécidive: ", ""));
						player.closeInventory();
						player.sendMessage(main.ecu+"§aEcrivez dans le tchat la commande sans le / , <player> remplacera le nom du joueur !");
						player.sendMessage(changeCommand.get(player));
						
					}
				}
			}
		}
	}
	
	@EventHandler
	public void onTchat(AsyncPlayerChatEvent event) {
		if(changeCommand.containsKey(event.getPlayer())) {
			event.setCancelled(true);
			String command = event.getMessage();
			String adress = changeCommand.get(event.getPlayer());
			String[] adressParts = adress.split(":");
			File fichier = new File(main.getDataFolder()+ File.separator + "data" + File.separator +"sanctions"+ File.separator +adressParts[0]+".yml");
			if(fichier.exists()) {
				FileConfiguration config = YamlConfiguration.loadConfiguration(fichier);
				config.set("recidive-cmd."+adressParts[1]+".command.cmd", command);
				try {
					config.save(fichier);
					event.getPlayer().sendMessage(main.ecu+"§aLa commande de cette sanction a bien pue étre enregistée !");
				}catch (Exception e) {
					event.getPlayer().sendMessage(main.ecu+"§cLe fichier de cette sanction n'as pas pue étre enregistré !");
				}
			}else {
				event.getPlayer().sendMessage(main.ecu+"§cLe fichier §b" +adressParts[0]+".yml §cn'éxiste pas !");
			}
			changeCommand.remove(event.getPlayer());
			
		}
	}
}
